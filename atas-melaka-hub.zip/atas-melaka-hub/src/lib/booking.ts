// Booking helpers for Atas Restaurant table reservations.
// Calendar integration wired via the platform booking API.

const BOOKING_API_URL = "https://backend.leadconnectorhq.com";
const VIBE_API_URL = "https://backend.leadconnectorhq.com/vibe-ai";

export const CALENDAR_ID = "tZuVx75UxXukxy88nJtD";
export const LOCATION_ID = "Ewf9ZXCZTSYWSUezOk3Y";

// Custom field IDs registered for this booking flow.
export const CUSTOM_FIELD_GUESTS = "ek76944iKrPCmVcU91pV";
export const CUSTOM_FIELD_TABLE = "U4v8SWDnHfCacMRcURXx";
export const CUSTOM_FIELD_BABY_CHAIR = "FAzGxtiXfGqojyItIV2M";

type CustomFieldValue = { id: string; field_value: string };

type BookingPayload = {
  locationId: string;
  calendarId: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  selectedSlot: string;
  selectedTimezone?: string;
  sessionId?: string;
  customFields?: CustomFieldValue[];
  notes?: string;
};

// Malaysia Time (MYT) — UTC+08:00. Fixed so availability and bookings are
// always interpreted in Melaka local time regardless of the visitor's device.
const getBrowserTimezone = () => "Asia/Kuala_Lumpur";

const clampAvailabilityRange = (startMs: number, endMs: number) => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const startDate = Math.max(startMs, today.getTime());
  const maxEndDate = startDate + 31 * 24 * 60 * 60 * 1000;
  const endDate = Math.min(Math.max(endMs, startDate), maxEndDate);

  return { startDate, endDate };
};

export const fetchCalendarFreeSlots = async (
  calendarId: string,
  startMs: number,
  endMs: number,
) => {
  const { startDate, endDate } = clampAvailabilityRange(startMs, endMs);
  const params = new URLSearchParams({
    startDate: String(startDate),
    endDate: String(endDate),
    timezone: getBrowserTimezone(),
  });

  const response = await fetch(`${BOOKING_API_URL}/calendars/${calendarId}/free-slots?${params}`);
  if (!response.ok) throw new Error("Failed to fetch calendar availability");
  return (await response.json()) as Record<string, { slots: string[] }>;
};

export const submitCalendarBooking = async (payload: BookingPayload) => {
  const response = await fetch(`${VIBE_API_URL}/booking/submit`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      ...payload,
      selectedTimezone: payload.selectedTimezone ?? getBrowserTimezone(),
      sessionId: payload.sessionId ?? crypto.randomUUID(),
      customFields: payload.customFields ?? [],
    }),
  });

  if (!response.ok) throw new Error("Booking submission failed");
  return response.json();
};
