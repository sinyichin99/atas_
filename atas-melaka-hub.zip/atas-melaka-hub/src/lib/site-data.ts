export const ATAS_LOGO_IMG =
  "https://vibe.filesafe.space/1791391034583947001/attachments/7e7379d8-3b33-44ff-98bc-df2c8985b17f.png";

export const HERO_IMG =
  "https://vibe.filesafe.space/1791391034583947001/attachments/1efffe47-8cc7-4b42-ae0c-0572509ba014.png";
export const ASIAN_IMG =
  "https://vibe.filesafe.space/1791391034583947001/attachments/6c60e4a4-ecd1-46a9-ba79-0205df47350e.png";
export const WESTERN_IMG =
  "https://assets.cdn.filesafe.space/Ewf9ZXCZTSYWSUezOk3Y/media/6ac3a82fb12649a512206916.jpeg";
export const DRINKS_IMG =
  "https://vibe.filesafe.space/1791391034583947001/attachments/93635dfd-3151-44cc-9508-7e44ec37f194.png";
export const EVENT_TABLE_IMG =
  "https://vibe.filesafe.space/1791391034583947001/attachments/ac40e111-9c8e-42de-8958-633d06271d50.jpg";
export const COURTYARD_IMG =
  "https://vibe.filesafe.space/1791391034583947001/attachments/e6413bb9-7f43-4281-a350-240742414955.png";
export const RIVERSIDE_IMG =
  "https://assets.cdn.filesafe.space/Ewf9ZXCZTSYWSUezOk3Y/media/6ab6981953ee44f56b35febd.jpeg";
export const ABOUT_BG_IMG =
  "https://vibe.filesafe.space/1791391034583947001/attachments/08443b54-4419-43a8-b8e0-b9b781ec5006.png";
export const PALM_LEAF_TOP_IMG =
  "https://vibe.filesafe.space/1791391034583947001/attachments/9409a85d-caea-4afd-b11b-083407534c50.png";
export const PALM_LEAF_BOTTOM_IMG =
  "https://vibe.filesafe.space/1791391034583947001/attachments/45504d8a-00de-40ed-ab5f-38b658df83af.png";
export const SEATING_PLAN_BG_IMG =
  "https://vibe.filesafe.space/1791391034583947001/attachments/68c45e34-980f-430b-987e-40f534fff932.png";
export const PASTA_IMG =
  "https://vibe.filesafe.space/1791391034583947001/attachments/95c6d14f-a98b-4436-ad27-63b2394f64a4.jpg";

export const MENU_PDF_URL =
  "https://assets.cdn.filesafe.space/Ewf9ZXCZTSYWSUezOk3Y/media/6ac715538c077584b4eb4120.pdf";

export interface FullMenuItem {
  code: string;
  name: string;
  price: string;
  desc: string;
  category:
    | "Asian"
    | "Ala Carte"
    | "Mains"
    | "Pizza"
    | "Pasta"
    | "Soup"
    | "Salad"
    | "Bites"
    | "Dessert"
    | "Beverages";
  tag?: string;
}

export const FEATURED_MENU_ITEMS: FullMenuItem[] = [
  {
    code: "N01",
    name: "Nasi Lemak Ayam Goreng Berempah",
    price: "RM 27.90",
    desc: "Crispy spiced fried chicken whole leg served with coconut-infused fragrant rice, sambal, boiled egg, roasted peanuts, anchovies & cucumber.",
    category: "Asian",
    tag: "Signature Dish",
  },
  {
    code: "N02",
    name: "Nasi Lemak Rendang Daging",
    price: "RM 23.90",
    desc: "Rich and tender slow-cooked beef stew in aromatic coconut spices, served with fragrant coconut rice & traditional condiments.",
    category: "Asian",
    tag: "Chef Special",
  },
  {
    code: "M01",
    name: "Australian Wagyu Striploin",
    price: "RM 87.90",
    desc: "Premium flame-grilled Australian Wagyu striploin, served with warm lyonnaise potatoes & crisp garden green salad.",
    category: "Mains",
    tag: "Premium Cut",
  },
  {
    code: "M08",
    name: "Char-Grilled Lamb Rack",
    price: "RM 55.90",
    desc: "Tender flame-grilled lamb rack paired with refreshing mint sauce, lyonnaise potatoes & fresh greens.",
    category: "Mains",
  },
  {
    code: "PA1",
    name: "Classic Chicken Bolognese Spaghetti",
    price: "RM 27.90",
    desc: "Spaghetti with minced chicken and mushroom in tomato saunce & parmesan cheese",
    category: "Pasta",
  },
  {
    code: "P07",
    name: "Seafood Marinara Pizza",
    price: "RM 45.90",
    desc: "Succulent shrimp & baby octopus in signature pomodoro sauce, generously topped with melted cheddar & mozzarella cheese.",
    category: "Pizza",
  },
];

export const FULL_MENU_CATEGORIES = [
  {
    id: "Asian",
    title: "Asian Specialties",
    subtitle: "Authentic local heritage & coconut-infused rice delights",
    items: [
      {
        code: "N01",
        name: "Nasi Lemak Ayam Goreng Berempah",
        price: "RM 27.90",
        desc: "Spiced fried chicken served with coconut-infused fragrant rice",
      },
      {
        code: "N02",
        name: "Nasi Lemak Rendang Daging",
        price: "RM 23.90",
        desc: "Rich and tender beef stew served with coconut-infused fragrant rice",
      },
      {
        code: "N03",
        name: "Nasi Lemak Kari Ayam",
        price: "RM 22.90",
        desc: "Potato curry chicken served with coconut-infused fragrant rice",
      },
      {
        code: "N04",
        name: "Nasi Lemak Kari Kambing",
        price: "RM 25.90",
        desc: "Aromatic curry mutton served with coconut-infused fragrant rice",
      },
      {
        code: "N05",
        name: "Nasi Lemak Sambal Sotong",
        price: "RM 21.90",
        desc: "Stir-fry squid sambal served with coconut-infused fragrant rice",
      },
      {
        code: "N06",
        name: "Curry Noodle Soup",
        price: "RM 19.90",
        desc: "Choice of yellow noodles or vermicelli (bihun) in savory curry broth",
      },
      {
        code: "N07",
        name: "Prawn Noodle Soup",
        price: "RM 22.90",
        desc: "Choice of yellow noodles or vermicelli (bihun) with succulent prawns",
      },
      {
        code: "N08",
        name: "Fish Ball Noodle Soup",
        price: "RM 19.90",
        desc: "Choice of yellow noodles or vermicelli (bihun) in clear fish ball soup",
      },
    ],
  },
  {
    id: "Ala Carte",
    title: "Ala Carte Add-ons",
    subtitle: "Traditional Malaysian side dishes & savory curries",
    items: [
      {
        code: "A02",
        name: "Nasi Lemak Biasa",
        price: "RM 11.90",
        desc: "Coconut rice with sambal, egg, anchovies, peanuts & vegetables",
      },
      {
        code: "A03",
        name: "Ayam Goreng Berempah",
        price: "RM 16.90",
        desc: "Spiced fried whole chicken leg",
      },
      {
        code: "A04",
        name: "Rendang Daging",
        price: "RM 14.90",
        desc: "Tender slow-cooked beef stew",
      },
      { code: "A05", name: "Kari Ayam", price: "RM 13.90", desc: "Flavorful potato curry chicken" },
      { code: "A06", name: "Kari Kambing", price: "RM 15.90", desc: "Rich curry mutton" },
      {
        code: "A07",
        name: "Sambal Sotong",
        price: "RM 12.90",
        desc: "Stir-fried squid in spicy sambal",
      },
      {
        code: "A08",
        name: "Sambal Petai",
        price: "RM 11.90",
        desc: "Stir-fry petai beans with sambal",
      },
      {
        code: "A09",
        name: "Sotong Kangkung",
        price: "RM 16.90",
        desc: "Fresh water spinach with cuttlefish in aromatic sauce",
      },
    ],
  },
  {
    id: "Mains",
    title: "Western Mains & Steaks",
    subtitle: "Flame-grilled steaks, chops & western comfort mains",
    items: [
      {
        code: "M01",
        name: "Australian Wagyu Striploin",
        price: "RM 87.90",
        desc: "Served with lyonnaise potato & green salad",
      },
      {
        code: "M02",
        name: "Australian Wagyu Ribeye",
        price: "RM 89.90",
        desc: "Served with lyonnaise potato & green salad",
      },
      {
        code: "M03",
        name: "Chicken & Caramelised Onion Roulade",
        price: "RM 39.90",
        desc: "Served with portobello mushroom sauce & bread of the day",
      },
      {
        code: "M04",
        name: "Piri Piri Spring Chicken",
        price: "RM 48.90",
        desc: "Served with yakitori corn pop & sweet potato fries",
      },
      {
        code: "M05",
        name: "Sizzling Boneless Chicken Thigh",
        price: "RM 37.90",
        desc: "Served with portobello mushroom sauce, potato wedges & salad",
      },
      {
        code: "M06",
        name: "Oven-Baked Yakitori Salmon Steak",
        price: "RM 52.90",
        desc: "Served with potato wedges & green salad",
      },
      {
        code: "M07",
        name: "Classic Fish and Chips",
        price: "RM 39.90",
        desc: "Served with green salad, french fries & tartar sauce",
      },
      {
        code: "M08",
        name: "Char-Grilled Lamb Rack",
        price: "RM 55.90",
        desc: "Served with mint sauce, lyonnaise potato & green salad",
      },
      {
        code: "M09",
        name: "Sizzling Lamb Shoulder",
        price: "RM 53.90",
        desc: "Served with black pepper sauce, potato wedges & green salad",
      },
    ],
  },
  {
    id: "Pizza",
    title: "Artisanal Pizzas",
    subtitle: "Freshly baked pizzas with rich sauces and stringy cheese",
    items: [
      {
        code: "P04",
        name: "Beef Pepperoni & Red Capsicum Pizza",
        price: "RM 39.90",
        desc: "In alfredo sauce topped with cheddar & mozzarella cheese",
      },
      {
        code: "P05",
        name: "Smoked Chicken & Portobello Mushroom Pizza",
        price: "RM 38.90",
        desc: "In alfredo sauce topped with cheddar & mozzarella cheese",
      },
      {
        code: "P06",
        name: "Portobello Mushroom & Caramelised Onion Pizza",
        price: "RM 36.90",
        desc: "In alfredo sauce topped with rocket & feta cheese [Vegetarian]",
      },
      {
        code: "P07",
        name: "Seafood Marinara Pizza",
        price: "RM 45.90",
        desc: "Shrimp and baby octopus in pomodoro sauce with cheddar & mozzarella",
      },
    ],
  },
  {
    id: "Pasta & Soup",
    title: "Pasta & Soups",
    subtitle: "Italian pastas & freshly crafted warm soups",
    items: [
      {
        code: "PA1",
        name: "Classic Chicken Bolognese Spaghetti",
        price: "RM 27.90",
        desc: "Minced chicken and mushroom in tomato sauce & parmesan cheese",
      },
      {
        code: "PA2",
        name: "Smoked Chicken Aglio Olio Spaghetti",
        price: "RM 27.90",
        desc: "Spaghetti tossed in garlic oil with smoked chicken",
      },
      {
        code: "PA3",
        name: "Creamy Portobello Mushroom Fettuccine",
        price: "RM 26.90",
        desc: "Fettuccine tossed in creamy alfredo sauce with mushrooms [Vegetarian]",
      },
      {
        code: "SP1",
        name: "Tomato Soup",
        price: "RM 15.90",
        desc: "Rich pomodoro soup served with crispy garlic bread",
      },
      {
        code: "SP2",
        name: "Mushroom Soup",
        price: "RM 15.90",
        desc: "Creamy mushroom soup served with warm garlic bread",
      },
    ],
  },
  {
    id: "Salad & Bites",
    title: "Salads & Appetizers",
    subtitle: "Crispy bites, fresh salads & light appetizers",
    items: [
      {
        code: "S01",
        name: "Crispy Enoki Mushroom Hand-Roll",
        price: "RM 24.90",
        desc: "Served with miso-sesame dressing",
      },
      {
        code: "S02",
        name: "Greek Salad",
        price: "RM 22.90",
        desc: "Feta cheese & balsamico vinaigrette",
      },
      {
        code: "S03",
        name: "Baby Octopus Salad",
        price: "RM 31.90",
        desc: "Tossed in sesame soy sauce",
      },
      {
        code: "BT1",
        name: "Sweet Potato Fries",
        price: "RM 10.90",
        desc: "Crispy golden sweet potato fries",
      },
      {
        code: "BT2",
        name: "Spiced Potato Wedges",
        price: "RM 10.90",
        desc: "Seasoned crispy potato wedges",
      },
      { code: "BT3", name: "French Fries", price: "RM 10.90", desc: "Classic salted potato fries" },
      {
        code: "BT4",
        name: "Boxing Chicken",
        price: "RM 20.90",
        desc: "Crispy marinated chicken drumettes",
      },
      {
        code: "BT5",
        name: "Crispy Squid Tentacles",
        price: "RM 16.90",
        desc: "Golden fried squid tentacles",
      },
      {
        code: "BT6",
        name: "Tempura Prawn Fritters",
        price: "RM 21.90",
        desc: "Crispy tempura prawns",
      },
    ],
  },
  {
    id: "Desserts",
    title: "Local & Sweet Desserts",
    subtitle: "Authentic Malaysian shaved ice & hot sizzling desserts",
    items: [
      {
        code: "D01",
        name: "Melaka Cendol",
        price: "RM 9.90",
        desc: "Shaved ice with fresh coconut milk, gula melaka syrup, red bean & pandan jelly",
      },
      {
        code: "D03",
        name: "Sizzling Brownie with Ice Cream",
        price: "RM 20.90",
        desc: "Warm chocolate brownie served on a sizzling plate topped with vanilla ice cream",
      },
    ],
  },
  {
    id: "Beverages",
    title: "Handcrafted Beverages & Drinks",
    subtitle: "Mix fruit jugs, local brews, fresh juices & ice-cold drinks",
    items: [
      {
        code: "MF1",
        name: "Atas Mix Fruits Watermelon Jug",
        price: "RM 27.90",
        desc: "Soda, mint, mixed fruits & fresh watermelon",
      },
      {
        code: "MF2",
        name: "Atas Mix Fruits Orange Jug",
        price: "RM 27.90",
        desc: "Soda, mint, mixed fruits & fresh orange",
      },
      {
        code: "MF3",
        name: "Ocean Deep Blue Jug",
        price: "RM 27.90",
        desc: "Soda, mint, ginger, lemongrass & lemon",
      },
      {
        code: "MF4",
        name: "Sparkling Blackcurrant Jug",
        price: "RM 27.90",
        desc: "Soda, mint, lychee & blackcurrant",
      },
      {
        code: "D04",
        name: "Kopi Tarik (Hot / Iced)",
        price: "RM 8.90 / RM 9.90",
        desc: "Local coffee brewed with condensed and evaporated milk",
      },
      {
        code: "D05",
        name: "Teh Tarik (Hot / Iced)",
        price: "RM 8.90 / RM 9.90",
        desc: "Local pulled tea with condensed and evaporated milk",
      },
      {
        code: "D12",
        name: "Sirap Bandung 3 Layer",
        price: "RM 12.90",
        desc: "Rose syrup with evaporated milk and a rich layer of gula melaka",
      },
      {
        code: "D09",
        name: "Milo Dinosaur",
        price: "RM 11.90",
        desc: "Rich iced chocolate topped with extra Milo powder",
      },
    ],
  },
];

export const MENU_ITEMS = FEATURED_MENU_ITEMS;

export const REVIEWS = [
  {
    name: "Christy Tiong",
    meta: "Local Guide · 42 reviews",
    when: "2 weeks ago",
    text: "The Nasi Lemak served with perfectly cooked fragrant coconut rice, rich sambal, and crispy fried chicken was juicy and tender! Riverside dining by the Malacca River is so peaceful and relaxing.",
  },
  {
    name: "Kai Schmidt",
    meta: "Local Guide · 88 reviews",
    when: "1 month ago",
    text: "The steak here is simply out of this world! Melt-in-your-mouth tenderness, perfectly flame-grilled ribeye with roasted potatoes. Easily beats out premium steakhouses in KL.",
  },
  {
    name: "Tania Lim",
    meta: "Local Guide · 15 reviews",
    when: "3 weeks ago",
    text: "The atmosphere, the flavors, and the hospitality were all exceptional. The Lamb Rendang Nasi Lemak was tender and packed with rich spice. One of our best dining experiences in Melaka!",
  },
  {
    name: "Amanda Tan",
    meta: "Verified Diner · 6 reviews",
    when: "2 months ago",
    text: "Fancy yet warm heritage decor. Indoor garden courtyard seating with the river view at sunset is breathtaking. Generous portions, beautifully plated, and handcrafted iced brews are top-tier.",
  },
  {
    name: "Marcus Lee",
    meta: "Local Guide · 31 reviews",
    when: "Recent",
    text: "From the moment we arrived at 1825 Gallery Hotel, the staff treated us like royalty. Every dish was full of flavor and the riverside table ambiance at night was magical.",
  },
  {
    name: "Nurul Hidayah",
    meta: "Local Guide · 120 reviews",
    when: "1 week ago",
    text: "Stunning riverside ambience and the food is absolutely on point. The Seafood Marinara Pizza was loaded with fresh prawns and baby octopus, and the Melaka Cendol was the perfect sweet finish. A hidden gem in Melaka!",
  },
];

export const GUEST_OPTIONS = [
  { value: "1", label: "1 Guest" },
  { value: "2", label: "2 Guests (Table for Two)" },
  { value: "3", label: "3 Guests" },
  { value: "4", label: "4 Guests" },
  { value: "5", label: "5 Guests" },
  { value: "6", label: "6 Guests" },
  { value: "8", label: "8 Guests (Large Banquet)" },
  { value: "10", label: "10+ Guests (Event Party)" },
];
