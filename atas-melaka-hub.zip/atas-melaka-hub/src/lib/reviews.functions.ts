import { createServerFn } from "@tanstack/react-start";
import { fetchLatestFiveStarReviews, type ReviewsResult } from "./reviews.server";

// Thin server-function wrapper. All runtime logic lives in reviews.server.ts.
export const getLatestReviews = createServerFn({ method: "GET" }).handler(
  async (): Promise<ReviewsResult | null> => {
    return fetchLatestFiveStarReviews();
  },
);
