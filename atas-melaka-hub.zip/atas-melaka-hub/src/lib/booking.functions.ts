import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import {
  LOCATION_ID,
  CALENDAR_ID,
  CUSTOM_FIELD_GUESTS,
  CUSTOM_FIELD_TABLE,
  CUSTOM_FIELD_BABY_CHAIR,
} from "./booking";

export const CUSTOM_FIELD_DECO = "oDkj7scAdJFHlSfWB4Jl";

const VIBE_API_URL = "https://backend.leadconnectorhq.com/vibe-ai";

// Malaysia Time (MYT) — UTC+08:00. Fixed so bookings are always in Melaka time.
const getBrowserTimezone = () => "Asia/Kuala_Lumpur";

const bookingSchema = z.object({
  firstName: z.string().min(1),
  lastName: z.string().min(1),
  email: z.string().min(1),
  phone: z.string().min(1),
  selectedSlot: z.string().min(1),
  guests: z.string().optional(),
  selectedTable: z.string().optional(),
  babyChair: z.boolean().optional(),
  decoSelection: z
    .object({
      type: z.enum(["atas", "birthday"]),
      pax: z.string(),
      price: z.string(),
    })
    .nullable()
    .optional(),
});

// Server-side booking submit — avoids browser CORS preflight on the cross-origin POST.
export const submitBooking = createServerFn({ method: "POST" })
  .validator((data) => bookingSchema.parse(data))
  .handler(async ({ data }) => {
    const decoLabel = data.decoSelection
      ? `${data.decoSelection.type === "atas" ? "Atas Table Deco ✨" : "Birthday Table Deco ❤️✨"} — ${data.decoSelection.pax} — ${data.decoSelection.price}`
      : null;

    const customFields = [
      ...(data.guests ? [{ id: CUSTOM_FIELD_GUESTS, field_value: data.guests }] : []),
      ...(data.selectedTable ? [{ id: CUSTOM_FIELD_TABLE, field_value: data.selectedTable }] : []),
      { id: CUSTOM_FIELD_BABY_CHAIR, field_value: data.babyChair ? "Yes" : "No" },
      ...(decoLabel ? [{ id: CUSTOM_FIELD_DECO, field_value: decoLabel }] : []),
    ];

    const notesParts: string[] = [];
    if (data.selectedTable) notesParts.push(`Requested table: ${data.selectedTable}`);
    if (decoLabel) notesParts.push(`Table deco: ${decoLabel}`);

    const payload = {
      locationId: LOCATION_ID,
      calendarId: CALENDAR_ID,
      firstName: data.firstName,
      lastName: data.lastName,
      email: data.email,
      phone: data.phone,
      selectedSlot: data.selectedSlot,
      selectedTimezone: getBrowserTimezone(),
      sessionId: crypto.randomUUID(),
      customFields,
      notes: notesParts.length ? notesParts.join(" | ") : undefined,
    };

    const response = await fetch(`${VIBE_API_URL}/booking/submit`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      const text = await response.text().catch(() => "");
      throw new Error(`Booking submission failed (${response.status}): ${text}`);
    }
    return response.json();
  });
