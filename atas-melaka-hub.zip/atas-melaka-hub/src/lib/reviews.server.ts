// Server-only helper: fetches the latest 5-star Google reviews for Atas Restaurant.
// Runs entirely on the server; reads API key + place id from process.env at call time.

const PLACES_BASE = "https://places.googleapis.com/v1";

export type GoogleReview = {
  name: string;
  meta: string;
  when: string;
  text: string;
  rating: number;
};

export type ReviewsResult = {
  rating: number;
  totalReviews: number;
  reviews: GoogleReview[];
};

const MELAKA_LATLNG = { lat: 2.1909, lng: 102.2529 };

// Resolve the Place ID: use GOOGLE_PLACES_ID if provided, otherwise Text Search.
async function resolvePlaceId(apiKey: string, name: string): Promise<string | null> {
  const explicit = process.env.GOOGLE_PLACES_ID;
  if (explicit) return explicit;

  const body = {
    textQuery: name,
    locationBias: {
      circle: {
        center: { latitude: MELAKA_LATLNG.lat, longitude: MELAKA_LATLNG.lng },
        radius: 20000,
      },
    },
    pageSize: 1,
  };

  const res = await fetch(`${PLACES_BASE}/places:searchText`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Goog-Api-Key": apiKey,
      "X-Goog-FieldMask": "places.id,places.displayName",
    },
    body: JSON.stringify(body),
  });
  if (!res.ok) return null;
  const data = (await res.json()) as { places?: { id: string }[] };
  return data.places?.[0]?.id ?? null;
}

function timeAgo(iso: string): string {
  const then = new Date(iso).getTime();
  if (Number.isNaN(then)) return "Recent";
  const diff = Date.now() - then;
  const days = Math.floor(diff / 86_400_000);
  if (days <= 0) return "Today";
  if (days === 1) return "1 day ago";
  if (days < 7) return `${days} days ago`;
  const weeks = Math.floor(days / 7);
  if (weeks === 1) return "1 week ago";
  if (weeks < 5) return `${weeks} weeks ago`;
  const months = Math.floor(days / 30);
  if (months === 1) return "1 month ago";
  if (months < 12) return `${months} months ago`;
  const years = Math.floor(days / 365);
  return years === 1 ? "1 year ago" : `${years} years ago`;
}

export async function fetchLatestFiveStarReviews(): Promise<ReviewsResult | null> {
  const apiKey = process.env.GOOGLE_PLACES_API_KEY;
  if (!apiKey) return null;

  const placeId = await resolvePlaceId(apiKey, "Atas Restaurant Melaka");
  if (!placeId) return null;

  const res = await fetch(`${PLACES_BASE}/places/${placeId}`, {
    method: "GET",
    headers: {
      "X-Goog-Api-Key": apiKey,
      "X-Goog-FieldMask":
        "rating,userRatingCount,reviews(authorAttribution(displayName),rating,text,publishTime,relativePublishTimeDescription)",
    },
  });
  if (!res.ok) return null;
  const data = (await res.json()) as {
    rating?: number;
    userRatingCount?: number;
    reviews?: Array<{
      rating: number;
      text: string;
      publishTime: string;
      relativePublishTimeDescription?: string;
      authorAttribution?: { displayName?: string };
    }>;
  };

  const all = data.reviews ?? [];
  const fiveStar = all
    .filter((r) => r.rating === 5 && r.text)
    .sort((a, b) => new Date(b.publishTime).getTime() - new Date(a.publishTime).getTime())
    .slice(0, 5)
    .map((r) => ({
      name: r.authorAttribution?.displayName ?? "Google Reviewer",
      meta: "Verified Google Review",
      when: r.relativePublishTimeDescription || timeAgo(r.publishTime),
      text: r.text,
      rating: r.rating,
    }));

  if (fiveStar.length === 0) return null;

  return {
    rating: data.rating ?? 5,
    totalReviews: data.userRatingCount ?? 0,
    reviews: fiveStar,
  };
}
