// Form tracking helpers for Atas Restaurant reservation form.
// Wires submitted form data into the CRM tracking pipeline.

type StandardTrackingFieldKey = string;
type RegisteredCustomFieldId = string;
type TrackingCustomField = { value?: unknown; label: string };
type TrackingFileField = { file?: File; label: string };
type TrackingImageDataField = { dataUrl?: string; label: string };

export const TRACKING_ID = "tk_0c1edf7658c341e0915b9c7a92029965";
export const TRACKING_LOCATION_ID = "Ewf9ZXCZTSYWSUezOk3Y";
export const TRACKING_PROJECT_ID = "1791391034583947001";

// Reuse the custom-field IDs registered for the booking flow.
export const TRACK_CUSTOM_GUESTS = "ek76944iKrPCmVcU91pV";
export const TRACK_CUSTOM_TABLE = "U4v8SWDnHfCacMRcURXx";
export const TRACK_CUSTOM_BABY_CHAIR = "FAzGxtiXfGqojyItIV2M";
export const TRACK_CUSTOM_DECO = "oDkj7scAdJFHlSfWB4Jl";

export const postTrackingEvent = (
  trackingPayload: Record<string, unknown> & {
    formData: Record<StandardTrackingFieldKey, unknown>;
    formLabels: Record<StandardTrackingFieldKey, string>;
  },
  options: {
    customFields?: Record<RegisteredCustomFieldId, TrackingCustomField>;
    fileFields?: Record<RegisteredCustomFieldId, TrackingFileField>;
    imageDataFields?: Record<RegisteredCustomFieldId, TrackingImageDataField>;
  } = {},
) => {
  const { customFields = {}, fileFields = {}, imageDataFields = {} } = options;
  const eventPayload = {
    ...trackingPayload,
    formData: { ...trackingPayload.formData },
    formLabels: { ...trackingPayload.formLabels },
  };
  const body = new FormData();

  for (const [key, field] of Object.entries(customFields)) {
    if (field.value === undefined) continue;
    eventPayload.formData[key] = field.value;
    eventPayload.formLabels[key] = field.label;
  }

  for (const [key, field] of Object.entries(imageDataFields)) {
    const dataUrl = field.dataUrl;
    if (!dataUrl) continue;
    if (!dataUrl.startsWith("data:image/")) {
      throw new Error("Image data field must be a data:image/* base64 string");
    }
    eventPayload.formData[key] = dataUrl;
    eventPayload.formLabels[key] = field.label;
  }

  for (const [key, field] of Object.entries(fileFields)) {
    const file = field.file;
    if (!file) continue;
    if (file.size > 50 * 1024 * 1024) {
      throw new Error("File must be 50 MB or smaller");
    }
    eventPayload.formData[key] = {
      filename: file.name,
      size: file.size,
      type: file.type || "application/octet-stream",
    };
    eventPayload.formLabels[key] = field.label;
    body.append(key, file, file.name);
  }

  for (const key of Object.keys(eventPayload.formData)) {
    eventPayload.formLabels[key] ||= key;
  }

  body.append("event", JSON.stringify(eventPayload));

  return fetch("https://backend.leadconnectorhq.com/external-tracking/events", {
    method: "POST",
    headers: { version: "2021-07-28" },
    body,
  });
};

export type ReservationTrackingInput = {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  date: string;
  time: string;
  guestLabel: string;
  selectedTable: string | null;
  babyChair: boolean;
  decoSelection?: {
    type: "atas" | "birthday";
    pax: string;
    price: string;
  } | null;
};

const buildOpportunityMeta = (input: ReservationTrackingInput) => {
  const fullName = `${input.firstName} ${input.lastName}`.trim();
  const opportunityName = `Reservation — ${fullName} — ${input.date} ${input.time}`.trim();

  // Per-head estimate so the opportunity carries a monetary value in the pipeline.
  const guestCount = Number.parseInt((input.guestLabel.match(/\d+/) || [])[0] || "0", 10);
  const baseValue = Math.max(guestCount, 1) * 45;

  // Add the selected table deco package price to the estimated value.
  const decoValue = input.decoSelection
    ? Number.parseInt((input.decoSelection.price.match(/\d+/) || [])[0] || "0", 10)
    : 0;
  const estimatedValue = baseValue + decoValue;

  return {
    opportunityName,
    pipelineStage: "New Reservation",
    monetaryValue: estimatedValue,
    reservationDate: input.date,
    reservationTime: input.time,
  };
};

const formatDecoLabel = (deco: NonNullable<ReservationTrackingInput["decoSelection"]>) =>
  `${deco.type === "atas" ? "Atas Table Deco ✨" : "Birthday Table Deco ❤️✨"} — ${deco.pax} — ${deco.price}`;

export type TrackReservationResult = { ok: boolean; status: number; error?: string };

export const trackReservation = async (
  input: ReservationTrackingInput,
): Promise<TrackReservationResult> => {
  const opportunityMeta = buildOpportunityMeta(input);

  const decoNote = input.decoSelection
    ? ` | Table Deco: ${formatDecoLabel(input.decoSelection)}`
    : "";

  const trackingPayload = {
    type: "external_form_submission",
    timestamp: Date.now(),
    formId: "atas-reservation-form",
    formData: {
      first_name: input.firstName,
      last_name: input.lastName,
      email: input.email,
      phone: input.phone,
      opportunity_name: opportunityMeta.opportunityName,
      pipeline_stage: opportunityMeta.pipelineStage,
      monetary_value: opportunityMeta.monetaryValue,
      calendar_notes: `Reservation requested for ${input.date} at ${input.time}${decoNote}`,
    },
    formLabels: {
      first_name: "Booking Name (First)",
      last_name: "Booking Name (Last)",
      email: "Email",
      phone: "Phone Number",
      opportunity_name: "Opportunity Name",
      pipeline_stage: "Pipeline Stage",
      monetary_value: "Estimated Value (RM)",
      calendar_notes: "Reservation Notes",
    },
    url: typeof window !== "undefined" ? window.location.href : "",
    title: typeof document !== "undefined" ? document.title : "Atas Restaurant",
    path: typeof window !== "undefined" ? window.location.pathname : "/",
    userAgent: typeof navigator !== "undefined" ? navigator.userAgent : "unknown",
    trackingId: TRACKING_ID,
    locationId: TRACKING_LOCATION_ID,
    projectId: TRACKING_PROJECT_ID,
    sessionId: crypto.randomUUID(),
    properties: {
      deviceType:
        typeof navigator !== "undefined" && /Mobile|Android|iPhone/i.test(navigator.userAgent)
          ? "mobile"
          : "desktop",
      source: "ai_studio",
      projectId: TRACKING_PROJECT_ID,
      formName: "Atas Restaurant Reservation",
      // Opportunity payload for the automated sales pipeline.
      opportunity: {
        name: opportunityMeta.opportunityName,
        stage: opportunityMeta.pipelineStage,
        monetaryValue: opportunityMeta.monetaryValue,
        currency: "RM",
        reservationDate: opportunityMeta.reservationDate,
        reservationTime: opportunityMeta.reservationTime,
        guests: input.guestLabel,
        table: input.selectedTable || null,
        babyChair: input.babyChair ? "Yes" : "No",
        tableDeco: input.decoSelection ? formatDecoLabel(input.decoSelection) : null,
      },
    },
  };

  try {
    const res = await postTrackingEvent(trackingPayload, {
      customFields: {
        [TRACK_CUSTOM_GUESTS]: {
          value: input.guestLabel,
          label: "Number of Guests",
        },
        ...(input.selectedTable
          ? {
              [TRACK_CUSTOM_TABLE]: {
                value: input.selectedTable,
                label: "Selected Table",
              },
            }
          : {}),
        [TRACK_CUSTOM_BABY_CHAIR]: {
          value: input.babyChair ? "Yes" : "No",
          label: "Baby Chair",
        },
        ...(input.decoSelection
          ? {
              [TRACK_CUSTOM_DECO]: {
                value: formatDecoLabel(input.decoSelection),
                label: "Table Deco Package",
              },
            }
          : {}),
      },
    });
    return { ok: res.ok, status: res.status };
  } catch (err) {
    return {
      ok: false,
      status: 0,
      error: err instanceof Error ? err.message : "Network error",
    };
  }
};
