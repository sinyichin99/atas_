import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Header } from "../components/site-header";
import { Footer } from "../components/site-footer";
import { Hero } from "../components/section-hero";
import { Categories } from "../components/section-categories";
import { About } from "../components/section-about";
import { Menu } from "../components/section-menu";
import { Seating } from "../components/section-seating";
import { Reservation } from "../components/section-reservation";
import { Reviews } from "../components/section-reviews";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Atas Restaurant Melaka — Flavors of Heritage & Riverside Dining" },
      {
        name: "description",
        content:
          "Atas Restaurant in Melaka — Asian delights, Western favourites and handcrafted drinks by the Malacca River. Reserve your table today.",
      },
      { property: "og:title", content: "Atas Restaurant Melaka" },
      {
        property: "og:description",
        content:
          "Flavors of Heritage and Riverside Dining in Melaka. Reserve a memorable dining experience.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  const [selectedTable, setSelectedTable] = useState<string | null>(null);
  const [decoSelection, setDecoSelection] = useState<{
    type: "atas" | "birthday";
    pax: string;
    price: string;
  } | null>(null);

  return (
    <div className="min-h-screen bg-[#12281D] font-sans text-slate-100 flex flex-col selection:bg-[#d88f4c] selection:text-white">
      <Header />
      <main className="flex-grow">
        <Hero />
        <Categories />
        <About decoSelection={decoSelection} onDecoSelect={setDecoSelection} />
        <Menu />
        <Seating selectedTable={selectedTable} onSelectTable={setSelectedTable} />
        <Reservation
          selectedTable={selectedTable}
          decoSelection={decoSelection}
          onDecoClear={() => setDecoSelection(null)}
        />
        <Reviews />
      </main>
      <Footer />
    </div>
  );
}
